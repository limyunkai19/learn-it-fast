# Learn It Fast
Easy transfer learning tool implemented in Pytorch

## Installation
`pip install git+https://github.com/limyunkai19/learn-it-fast`

## Known issue
saved weight is in cuda
